// import { Routes } from '@angular/router';
// import { SignupComponent } from './signup/signup.component';
// import { SigninComponent } from './signin/signin.component';
// import { UdashboardComponent } from './udashboard/udashboard.component';
// import { ProfileComponent } from './profile/profile.component';
// import { ContentComponent } from './content/content.component';

// export const routes: Routes = [
//     {path:'signup', component: SignupComponent },
//     {path:"",component:SigninComponent},
//     // {path:"*",component:UdashboardComponent},
//     // {path:",",component:ProfileComponent}
//     { path: 'dashboard', component: UdashboardComponent, children: [
//         { path: 'profile', component: ProfileComponent },
//         { path: 'content', component: ContentComponent },

//         { path: '', redirectTo: 'content', pathMatch: 'full' }
//     ]}  
// ];
// import { PreventDuplicateRouteGuard } from './guards/prevent-duplicate-route.guard'; 

import { Routes } from '@angular/router';
import { SignupComponent } from './signup/signup.component';
import { SigninComponent } from './signin/signin.component';
import { UdashboardComponent } from './udashboard/udashboard.component';
import { ProfileComponent } from './profile/profile.component';
import { ContentComponent } from './content/content.component';

export const routes: Routes = [
    { path: 'signup', component: SignupComponent },
    { path: '', component: SigninComponent },
    // { path: 'dashboard', component: UdashboardComponent, children: [
        { path: 'profile', component: ProfileComponent },
        { path: 'content', component: ContentComponent },
        { path: '', redirectTo: 'content', pathMatch: 'full' } 
    // ]}
];
